# Online Banking System

A secure **Online Banking System** built with **Java, Spring Boot, Spring Security, Thymeleaf, and MySQL**. The application provides separate dashboards and functionality for **Customers** and **Administrators**.

## 🚀 Features

### 👤 Customer Module

* Customer registration and login
* Customer dashboard
* Account creation
* Account overview and details
* Deposit money
* Withdraw money
* Transfer money
* Transaction history
* Profile management
* Password management
* Banking services
* Loans and investment information
* Account status management

### 🛡️ Admin Module

* Admin authentication
* Admin dashboard
* User management
* Edit customer information
* Activate users
* Deactivate users
* Block users
* User/account status synchronization
* Transaction monitoring
* Transaction filtering
* System settings
* Maintenance mode
* Maximum transfer limit
* Minimum account balance
* Operational metrics

### 🔐 Security

* Spring Security authentication
* Role-based authorization
* Separate `ADMIN` and `CUSTOMER` roles
* Protected customer routes
* Protected admin routes
* Password encryption
* Login/logout handling
* Blocked/inactive customer restrictions
* Banking-operation validation
* 403 and 404 error pages

---

## 🛠️ Technology Stack

| Technology      | Purpose                        |
| --------------- | ------------------------------ |
| Java 17         | Programming language           |
| Spring Boot     | Backend framework              |
| Spring Security | Authentication & authorization |
| Spring Data JPA | Database persistence           |
| Hibernate       | ORM                            |
| Thymeleaf       | Server-side UI                 |
| MySQL           | Database                       |
| Maven           | Build & dependency management  |
| HTML/CSS        | Frontend                       |

---

## 📁 Project Structure

```text
online-banking-system/
│
├── src/
│   └── main/
│       ├── java/
│       │   └── com/
│       │       └── om/
│       │           └── banking/
│       │               ├── controller/
│       │               ├── service/
│       │               ├── repository/
│       │               ├── entity/
│       │               ├── dto/
│       │               ├── security/
│       │               └── exception/
│       │
│       └── resources/
│           ├── templates/
│           ├── static/
│           │   └── css/
│           └── application.properties
│
├── pom.xml
├── mvnw
├── mvnw.cmd
└── README.md
```

---

## 🗄️ Database Setup

Create a MySQL database:

```sql
CREATE DATABASE online_banking;
```

Then configure your database connection in:

```text
src/main/resources/application.properties
```

Example:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/online_banking
spring.datasource.username=root
spring.datasource.password=${DB_PASSWORD}

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

spring.thymeleaf.cache=false

server.port=8080
```

> **Security:** Do not commit your real MySQL password to GitHub.

For local development, you can configure the `DB_PASSWORD` environment variable.

---

## ▶️ How to Run

### 1. Clone the repository

```bash
git clone https://github.com/omsharma10/online-banking-system.git
```

### 2. Open the project

Open the project in:

* IntelliJ IDEA
* VS Code
* Eclipse
* Any Java IDE supporting Maven

### 3. Configure MySQL

Make sure MySQL is running and the database exists:

```sql
CREATE DATABASE online_banking;
```

### 4. Configure database credentials

Set:

```text
DB_PASSWORD
```

to your MySQL password.

### 5. Build the project

Windows:

```powershell
.\mvnw.cmd clean compile
```

### 6. Run the application

```powershell
.\mvnw.cmd spring-boot:run
```

Or run:

```text
OnlineBankingSystemApplication.java
```

from your IDE.

### 7. Open the application

```text
http://localhost:8080
```

---

## 👥 User Roles

The system contains two primary roles:

### Administrator

```text
ADMIN
```

Administrators can manage users, monitor transactions, and configure system settings.

### Customer

```text
CUSTOMER
```

Customers can manage their accounts and perform banking operations.

---

## 💰 Banking Operations

Customers can perform:

```text
Deposit
   ↓
Account Balance

Withdraw
   ↓
Account Balance

Transfer
   ↓
Recipient Account
   ↓
Transaction Record
```

Every transaction is recorded with information such as:

* Transaction reference
* Account
* Transaction type
* Amount
* Status
* Description
* Date/time

---

## ⚙️ System Settings

Administrators can configure:

```text
Bank Name
Support Email
Maintenance Mode
Maximum Transfer Amount
Minimum Account Balance
```

These settings are applied to relevant banking operations.

---

## 🔒 Account & User Status

Users can have statuses such as:

```text
ACTIVE
INACTIVE
BLOCKED
```

Accounts can have statuses such as:

```text
ACTIVE
INACTIVE
BLOCKED
CLOSED
```

The system synchronizes user status with associated account status when administrators activate, deactivate, or block customers.

---

## 🧪 Testing

Important scenarios tested include:

* Customer registration
* Customer login
* Admin login
* Account creation
* Deposit
* Withdrawal
* Money transfer
* Transaction history
* Profile updates
* User activation
* User deactivation
* User blocking
* Role-based access
* Maintenance mode
* Transfer limits
* Minimum balance validation
* Insufficient balance
* Unauthorized page access
* Logout
* 403/404 handling

---

## 🖥️ Application Screens

Add your screenshots here after taking them from the final application.

```text
docs/
└── screenshots/
    ├── home.png
    ├── login.png
    ├── customer-dashboard.png
    ├── account-details.png
    ├── transactions.png
    ├── admin-dashboard.png
    ├── user-management.png
    └── system-settings.png
```

Example:

```markdown
![Customer Dashboard](docs/screenshots/customer-dashboard.png)
```

---

## 🔮 Future Enhancements

Possible future improvements include:

* Email notifications
* OTP authentication
* Two-factor authentication
* PDF bank statements
* UPI/payment integration
* Credit/debit card management
* Loan application workflow
* Investment portfolio management
* Advanced analytics
* Transaction export
* Cloud deployment
* Mobile application

---

## 🎓 Academic Project

**Project:** Online Banking System

**Domain:** Banking / FinTech

**Backend:** Java + Spring Boot

**Frontend:** Thymeleaf + HTML/CSS

**Database:** MySQL

**Security:** Spring Security

---

## 👨‍💻 Developer

**Om Sharma**

B.Tech CSE — Cybersecurity

---

## 📄 License

This project is developed for **educational and academic purposes**.
