package com.om.banking.controller;

import com.om.banking.entity.SystemSettings;
import com.om.banking.service.SystemSettingsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@Controller
public class AdminSettingsController {

    private final SystemSettingsService systemSettingsService;

    public AdminSettingsController(
            SystemSettingsService systemSettingsService
    ) {
        this.systemSettingsService =
                systemSettingsService;
    }


    // =========================================================
    // SYSTEM SETTINGS PAGE
    // =========================================================

    @GetMapping("/admin/settings")
    public String settingsPage(
            Model model
    ) {

        SystemSettings settings =
                systemSettingsService.getSettings();

        model.addAttribute(
                "settings",
                settings
        );

        return "admin-settings";
    }


    // =========================================================
    // UPDATE SYSTEM SETTINGS
    // =========================================================

    @PostMapping("/admin/settings")
    public String updateSettings(

            @RequestParam("bankName")
            String bankName,

            @RequestParam("supportEmail")
            String supportEmail,

            @RequestParam(
                    value = "maintenanceMode",
                    required = false
            )
            Boolean maintenanceMode,

            @RequestParam("maximumTransferAmount")
            BigDecimal maximumTransferAmount,

            @RequestParam("minimumAccountBalance")
            BigDecimal minimumAccountBalance

    ) {

        try {

            systemSettingsService.updateSettings(

                    bankName,

                    supportEmail,

                    Boolean.TRUE.equals(
                            maintenanceMode
                    ),

                    maximumTransferAmount,

                    minimumAccountBalance
            );

            return "redirect:/admin/settings?success";

        } catch (
                IllegalArgumentException exception
        ) {

            return "redirect:/admin/settings?error="
                    + encodeMessage(
                    exception.getMessage()
            );
        }
    }


    // =========================================================
    // MESSAGE ENCODING
    // =========================================================

    private String encodeMessage(
            String message
    ) {

        if (message == null ||
                message.trim().isEmpty()) {

            return "Settings+update+failed.";
        }

        return message
                .replace(
                        " ",
                        "+"
                );
    }
}