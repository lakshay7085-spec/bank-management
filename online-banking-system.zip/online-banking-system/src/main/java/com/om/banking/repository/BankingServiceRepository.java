package com.om.banking.repository;

import com.om.banking.entity.BankingService;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BankingServiceRepository extends JpaRepository<BankingService, Long> {

    Optional<BankingService> findByServiceName(String serviceName);

    Optional<BankingService> findByServiceType(
            BankingService.ServiceType serviceType
    );

    List<BankingService> findByStatus(
            BankingService.ServiceStatus status
    );

    boolean existsByServiceName(String serviceName);
}