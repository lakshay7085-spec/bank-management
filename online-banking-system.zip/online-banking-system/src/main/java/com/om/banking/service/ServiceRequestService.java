package com.om.banking.service;

import com.om.banking.entity.BankingService;
import com.om.banking.entity.ServiceRequest;
import com.om.banking.entity.User;
import com.om.banking.repository.ServiceRequestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ServiceRequestService {

    private final ServiceRequestRepository serviceRequestRepository;

    public ServiceRequestService(
            ServiceRequestRepository serviceRequestRepository
    ) {
        this.serviceRequestRepository = serviceRequestRepository;
    }

    // Create a service request
    @Transactional
    public ServiceRequest createRequest(
            User user,
            BankingService bankingService,
            String remarks
    ) {

        if (bankingService.getStatus()
                != BankingService.ServiceStatus.ACTIVE) {

            throw new IllegalArgumentException(
                    "This banking service is currently unavailable."
            );
        }

        ServiceRequest request = new ServiceRequest();

        request.setUser(user);
        request.setBankingService(bankingService);
        request.setStatus(
                ServiceRequest.RequestStatus.PENDING
        );
        request.setRemarks(remarks);
        request.setRequestedAt(LocalDateTime.now());

        return serviceRequestRepository.save(request);
    }

    // Get request by ID
    public ServiceRequest getRequestById(Long id) {

        return serviceRequestRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Service request not found."
                        )
                );
    }

    // Get requests of a user
    public List<ServiceRequest> getUserRequests(User user) {

        return serviceRequestRepository.findByUser(user);
    }

    // Get requests by user ID
    public List<ServiceRequest> getUserRequestsByUserId(
            Long userId
    ) {

        return serviceRequestRepository.findByUserId(userId);
    }

    // Get pending requests
    public List<ServiceRequest> getPendingRequests() {

        return serviceRequestRepository.findByStatus(
                ServiceRequest.RequestStatus.PENDING
        );
    }

    // Approve request
    @Transactional
    public ServiceRequest approveRequest(Long id) {

        ServiceRequest request = getRequestById(id);

        validatePendingRequest(request);

        request.setStatus(
                ServiceRequest.RequestStatus.APPROVED
        );

        request.setProcessedAt(LocalDateTime.now());

        return serviceRequestRepository.save(request);
    }

    // Reject request
    @Transactional
    public ServiceRequest rejectRequest(
            Long id,
            String remarks
    ) {

        ServiceRequest request = getRequestById(id);

        validatePendingRequest(request);

        request.setStatus(
                ServiceRequest.RequestStatus.REJECTED
        );

        request.setRemarks(remarks);
        request.setProcessedAt(LocalDateTime.now());

        return serviceRequestRepository.save(request);
    }

    // Complete request
    @Transactional
    public ServiceRequest completeRequest(Long id) {

        ServiceRequest request = getRequestById(id);

        if (request.getStatus()
                != ServiceRequest.RequestStatus.APPROVED) {

            throw new IllegalArgumentException(
                    "Only approved requests can be completed."
            );
        }

        request.setStatus(
                ServiceRequest.RequestStatus.COMPLETED
        );

        request.setProcessedAt(LocalDateTime.now());

        return serviceRequestRepository.save(request);
    }

    // Validate pending request
    private void validatePendingRequest(
            ServiceRequest request
    ) {

        if (request.getStatus()
                != ServiceRequest.RequestStatus.PENDING) {

            throw new IllegalArgumentException(
                    "Only pending requests can be processed."
            );
        }
    }
}