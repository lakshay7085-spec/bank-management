package com.om.banking.service;

import com.om.banking.entity.Account;
import com.om.banking.entity.User;
import com.om.banking.repository.AccountRepository;
import com.om.banking.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final AccountRepository accountRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            UserRepository userRepository,
            AccountRepository accountRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // =========================================================
    // CREATE USER
    // =========================================================

    @Transactional
    public User createUser(User user) {

        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException(
                    "A user with this email already exists."
            );
        }

        user.setPassword(
                passwordEncoder.encode(user.getPassword())
        );

        if (user.getRole() == null) {
            user.setRole(User.Role.CUSTOMER);
        }

        if (user.getStatus() == null) {
            user.setStatus(User.UserStatus.ACTIVE);
        }

        return userRepository.save(user);
    }

    // =========================================================
    // FIND USER BY ID
    // =========================================================

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    // =========================================================
    // FIND USER BY EMAIL
    // =========================================================

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // =========================================================
    // GET ALL USERS
    // =========================================================

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // =========================================================
    // ADMIN - UPDATE USER
    // =========================================================

    @Transactional
    public User updateUser(
            Long id,
            User updatedUser
    ) {

        User existingUser =
                userRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        existingUser.setName(
                updatedUser.getName()
        );

        existingUser.setPhone(
                updatedUser.getPhone()
        );

        existingUser.setRole(
                updatedUser.getRole()
        );

        User.UserStatus oldStatus =
                existingUser.getStatus();

        User.UserStatus newStatus =
                updatedUser.getStatus();

        existingUser.setStatus(newStatus);

        User savedUser =
                userRepository.save(existingUser);

        // Synchronize account status with user status
        synchronizeAccountStatus(
                savedUser,
                newStatus
        );

        return savedUser;
    }

    // =========================================================
    // CUSTOMER - UPDATE PROFILE
    // =========================================================

    @Transactional
    public User updateProfile(
            Long id,
            String name,
            String email,
            String phone,
            String newPassword
    ) {

        User user =
                userRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        // Validate name
        if (name == null ||
                name.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Name cannot be empty."
            );
        }

        // Validate email
        if (email == null ||
                email.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Email cannot be empty."
            );
        }

        String cleanEmail =
                email.trim().toLowerCase();

        // Check email change
        if (!cleanEmail.equals(
                user.getEmail()
        )) {

            Optional<User> existingEmail =
                    userRepository.findByEmail(
                            cleanEmail
                    );

            if (existingEmail.isPresent() &&
                    !existingEmail.get()
                            .getId()
                            .equals(id)) {

                throw new IllegalArgumentException(
                        "Another user already uses this email."
                );
            }

            user.setEmail(
                    cleanEmail
            );
        }

        // Update name
        user.setName(
                name.trim()
        );

        // Update phone
        if (phone != null) {

            user.setPhone(
                    phone.trim()
            );
        }

        // Update password
        if (newPassword != null &&
                !newPassword.trim().isEmpty()) {

            if (newPassword.length() < 8) {

                throw new IllegalArgumentException(
                        "Password must contain at least 8 characters."
                );
            }

            user.setPassword(
                    passwordEncoder.encode(
                            newPassword
                    )
            );
        }

        return userRepository.save(user);
    }

    // =========================================================
    // UPDATE PASSWORD
    // =========================================================

    @Transactional
    public User updatePassword(
            Long id,
            String newPassword
    ) {

        if (newPassword == null ||
                newPassword.length() < 8) {

            throw new IllegalArgumentException(
                    "Password must contain at least 8 characters."
            );
        }

        User user =
                userRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        user.setPassword(
                passwordEncoder.encode(
                        newPassword
                )
        );

        return userRepository.save(user);
    }

    // =========================================================
    // DELETE USER
    // =========================================================

    @Transactional
    public void deleteUser(Long id) {

        if (!userRepository.existsById(id)) {

            throw new IllegalArgumentException(
                    "User not found."
            );
        }

        userRepository.deleteById(id);
    }

    // =========================================================
    // ACTIVATE USER
    // =========================================================

    @Transactional
    public User activateUser(Long id) {

        User user =
                userRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        user.setStatus(
                User.UserStatus.ACTIVE
        );

        User savedUser =
                userRepository.save(user);

        synchronizeAccountStatus(
                savedUser,
                User.UserStatus.ACTIVE
        );

        return savedUser;
    }

    // =========================================================
    // DEACTIVATE USER
    // =========================================================

    @Transactional
    public User deactivateUser(Long id) {

        User user =
                userRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        user.setStatus(
                User.UserStatus.INACTIVE
        );

        User savedUser =
                userRepository.save(user);

        synchronizeAccountStatus(
                savedUser,
                User.UserStatus.INACTIVE
        );

        return savedUser;
    }

    // =========================================================
    // BLOCK USER
    // =========================================================

    @Transactional
    public User blockUser(Long id) {

        User user =
                userRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        user.setStatus(
                User.UserStatus.BLOCKED
        );

        User savedUser =
                userRepository.save(user);

        synchronizeAccountStatus(
                savedUser,
                User.UserStatus.BLOCKED
        );

        return savedUser;
    }

    // =========================================================
    // SYNCHRONIZE ACCOUNT STATUS
    // =========================================================

    private void synchronizeAccountStatus(
            User user,
            User.UserStatus userStatus
    ) {

        List<Account> accounts =
                accountRepository.findByUser(user);

        if (accounts == null ||
                accounts.isEmpty()) {
            return;
        }

        Account.AccountStatus accountStatus;

        if (userStatus == User.UserStatus.ACTIVE) {

            accountStatus =
                    Account.AccountStatus.ACTIVE;

        } else if (userStatus == User.UserStatus.BLOCKED) {

            accountStatus =
                    Account.AccountStatus.BLOCKED;

        } else {

            accountStatus =
                    Account.AccountStatus.INACTIVE;
        }

        for (Account account : accounts) {

            account.setStatus(accountStatus);

            accountRepository.save(account);
        }
    }
}