package com.om.banking.controller;

import com.om.banking.dto.RegisterRequest;
import com.om.banking.entity.User;
import com.om.banking.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // Login page
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    // Registration page
    @GetMapping("/register")
    public String registerPage(Model model) {

        model.addAttribute(
                "registerRequest",
                new RegisterRequest()
        );

        return "register";
    }

    // Process registration
    @PostMapping("/register")
    public String registerUser(
            @Valid
            @ModelAttribute("registerRequest")
            RegisterRequest request,

            BindingResult bindingResult,

            Model model
    ) {

        if (bindingResult.hasErrors()) {
            return "register";
        }

        try {

            User user = new User();

            user.setName(request.getName());
            user.setEmail(request.getEmail());
            user.setPassword(request.getPassword());
            user.setPhone(request.getPhone());

            user.setRole(User.Role.CUSTOMER);
            user.setStatus(User.UserStatus.ACTIVE);

            userService.createUser(user);

            return "redirect:/login?registered";

        } catch (IllegalArgumentException exception) {

            model.addAttribute(
                    "error",
                    exception.getMessage()
            );

            return "register";
        }
    }
}