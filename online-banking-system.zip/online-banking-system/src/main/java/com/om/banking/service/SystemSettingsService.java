package com.om.banking.service;

import com.om.banking.entity.SystemSettings;
import com.om.banking.repository.SystemSettingsRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class SystemSettingsService {

    private static final Long SETTINGS_ID = 1L;

    private final SystemSettingsRepository
            settingsRepository;


    public SystemSettingsService(
            SystemSettingsRepository settingsRepository
    ) {
        this.settingsRepository =
                settingsRepository;
    }


    // =========================================================
    // GET SETTINGS
    // =========================================================

    @Transactional
    public SystemSettings getSettings() {

        return settingsRepository
                .findById(SETTINGS_ID)
                .orElseGet(() -> {

                    SystemSettings settings =
                            new SystemSettings();

                    settings.setId(SETTINGS_ID);

                    settings.setBankName(
                            "Online Banking System"
                    );

                    settings.setSupportEmail(
                            "support@banking.com"
                    );

                    settings.setMaintenanceMode(
                            false
                    );

                    settings.setMaximumTransferAmount(
                            new BigDecimal("100000.00")
                    );

                    settings.setMinimumAccountBalance(
                            new BigDecimal("0.00")
                    );

                    return settingsRepository.save(
                            settings
                    );
                });
    }


    // =========================================================
    // UPDATE SETTINGS
    // =========================================================

    @Transactional
    public SystemSettings updateSettings(
            String bankName,
            String supportEmail,
            boolean maintenanceMode,
            BigDecimal maximumTransferAmount,
            BigDecimal minimumAccountBalance
    ) {

        if (bankName == null ||
                bankName.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Bank name cannot be empty."
            );
        }


        if (supportEmail == null ||
                supportEmail.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Support email cannot be empty."
            );
        }


        if (maximumTransferAmount == null ||
                maximumTransferAmount
                        .compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException(
                    "Maximum transfer amount must be greater than zero."
            );
        }


        if (minimumAccountBalance == null ||
                minimumAccountBalance
                        .compareTo(BigDecimal.ZERO) < 0) {

            throw new IllegalArgumentException(
                    "Minimum account balance cannot be negative."
            );
        }


        if (minimumAccountBalance
                .compareTo(maximumTransferAmount) > 0) {

            throw new IllegalArgumentException(
                    "Minimum account balance cannot exceed maximum transfer amount."
            );
        }


        SystemSettings settings =
                getSettings();


        settings.setBankName(
                bankName.trim()
        );

        settings.setSupportEmail(
                supportEmail.trim()
        );

        settings.setMaintenanceMode(
                maintenanceMode
        );

        settings.setMaximumTransferAmount(
                maximumTransferAmount
        );

        settings.setMinimumAccountBalance(
                minimumAccountBalance
        );


        return settingsRepository.save(
                settings
        );
    }
}