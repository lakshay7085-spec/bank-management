package com.om.banking.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(
            nullable = false,
            unique = true,
            length = 50
    )
    private String transactionReference;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "account_id",
            nullable = false
    )
    private Account account;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType transactionType;

    @Column(
            nullable = false,
            precision = 15,
            scale = 2
    )
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status;

    @Column(length = 255)
    private String description;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    // =========================================================
    // DEFAULT CONSTRUCTOR
    // =========================================================

    public Transaction() {
    }

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public Transaction(
            Account account,
            TransactionType transactionType,
            BigDecimal amount,
            TransactionStatus status,
            String description
    ) {

        this.account = account;
        this.transactionType = transactionType;
        this.amount = amount;
        this.status = status;
        this.description = description;
    }

    // =========================================================
    // PRE-PERSIST
    // =========================================================

    @PrePersist
    protected void onCreate() {

        if (transactionReference == null) {

            transactionReference =
                    "TXN-"
                            + UUID.randomUUID()
                            .toString()
                            .replace("-", "")
                            .substring(0, 16)
                            .toUpperCase();
        }

        if (createdAt == null) {

            createdAt = LocalDateTime.now();
        }

        if (status == null) {

            status = TransactionStatus.SUCCESS;
        }
    }

    // =========================================================
    // GETTERS AND SETTERS
    // =========================================================

    public Long getId() {

        return id;
    }

    public void setId(Long id) {

        this.id = id;
    }

    public String getTransactionReference() {

        return transactionReference;
    }

    public void setTransactionReference(
            String transactionReference
    ) {

        this.transactionReference =
                transactionReference;
    }

    public Account getAccount() {

        return account;
    }

    public void setAccount(Account account) {

        this.account = account;
    }

    public TransactionType getTransactionType() {

        return transactionType;
    }

    public void setTransactionType(
            TransactionType transactionType
    ) {

        this.transactionType =
                transactionType;
    }

    public BigDecimal getAmount() {

        return amount;
    }

    public void setAmount(BigDecimal amount) {

        this.amount = amount;
    }

    public TransactionStatus getStatus() {

        return status;
    }

    public void setStatus(
            TransactionStatus status
    ) {

        this.status = status;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(
            String description
    ) {

        this.description = description;
    }

    public LocalDateTime getCreatedAt() {

        return createdAt;
    }

    public void setCreatedAt(
            LocalDateTime createdAt
    ) {

        this.createdAt = createdAt;
    }

    // =========================================================
    // ENUMS
    // =========================================================

    public enum TransactionType {

        DEPOSIT,
        WITHDRAW,
        TRANSFER
    }

    public enum TransactionStatus {

        PENDING,
        SUCCESS,
        FAILED
    }
}