package com.om.banking.service;

import com.om.banking.entity.Account;
import com.om.banking.entity.Transaction;
import com.om.banking.entity.User;
import com.om.banking.repository.AccountRepository;
import com.om.banking.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class TransactionService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final SystemSettingsService systemSettingsService;

    public TransactionService(
            AccountRepository accountRepository,
            TransactionRepository transactionRepository,
            SystemSettingsService systemSettingsService
    ) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.systemSettingsService = systemSettingsService;
    }

    // =========================================================
    // TRANSFER MONEY
    // =========================================================

    @Transactional
    public Transaction transferMoney(
            String senderAccountNumber,
            String receiverAccountNumber,
            BigDecimal amount
    ) {

        // Check maintenance mode
        if (systemSettingsService.getSettings().isMaintenanceMode()) {
            throw new IllegalArgumentException(
                    "Banking operations are currently unavailable due to maintenance."
            );
        }

        // Validate sender account number
        if (senderAccountNumber == null ||
                senderAccountNumber.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Sender account number is required."
            );
        }

        // Validate receiver account number
        if (receiverAccountNumber == null ||
                receiverAccountNumber.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Receiver account number is required."
            );
        }

        // Same account check
        if (senderAccountNumber.equals(receiverAccountNumber)) {

            throw new IllegalArgumentException(
                    "Sender and receiver accounts cannot be the same."
            );
        }

        // Amount validation
        if (amount == null ||
                amount.compareTo(BigDecimal.ZERO) <= 0) {

            throw new IllegalArgumentException(
                    "Transfer amount must be greater than zero."
            );
        }

        // Get system settings
        var settings = systemSettingsService.getSettings();

        // Maximum transfer validation
        if (amount.compareTo(
                settings.getMaximumTransferAmount()
        ) > 0) {

            throw new IllegalArgumentException(
                    "Transfer amount exceeds the maximum allowed limit of ₹"
                            + settings.getMaximumTransferAmount()
            );
        }

        // Find sender
        Account sender =
                accountRepository
                        .findByAccountNumber(senderAccountNumber)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Sender account not found."
                                )
                        );

        // Find receiver
        Account receiver =
                accountRepository
                        .findByAccountNumber(receiverAccountNumber)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Receiver account not found."
                                )
                        );

        // =====================================================
        // CHECK SENDER USER STATUS
        // =====================================================

        validateUserIsActive(
                sender.getUser(),
                "Sender"
        );

        // =====================================================
        // CHECK RECEIVER USER STATUS
        // =====================================================

        validateUserIsActive(
                receiver.getUser(),
                "Receiver"
        );

        // =====================================================
        // CHECK SENDER ACCOUNT STATUS
        // =====================================================

        if (sender.getStatus()
                != Account.AccountStatus.ACTIVE) {

            throw new IllegalArgumentException(
                    "Sender account is not active."
            );
        }

        // =====================================================
        // CHECK RECEIVER ACCOUNT STATUS
        // =====================================================

        if (receiver.getStatus()
                != Account.AccountStatus.ACTIVE) {

            throw new IllegalArgumentException(
                    "Receiver account is not active."
            );
        }

        // =====================================================
        // CHECK BALANCE
        // =====================================================

        if (sender.getBalance()
                .compareTo(amount) < 0) {

            throw new IllegalArgumentException(
                    "Insufficient account balance."
            );
        }

        // =====================================================
        // CHECK MINIMUM BALANCE
        // =====================================================

        BigDecimal remainingBalance =
                sender.getBalance()
                        .subtract(amount);

        if (remainingBalance.compareTo(
                settings.getMinimumAccountBalance()
        ) < 0) {

            throw new IllegalArgumentException(
                    "Transfer denied. Your account must maintain a minimum balance of ₹"
                            + settings.getMinimumAccountBalance()
            );
        }

        // =====================================================
        // UPDATE BALANCES
        // =====================================================

        sender.setBalance(
                sender.getBalance()
                        .subtract(amount)
        );

        receiver.setBalance(
                receiver.getBalance()
                        .add(amount)
        );

        accountRepository.save(sender);
        accountRepository.save(receiver);

        // =====================================================
        // CREATE SENDER TRANSACTION
        // =====================================================

        Transaction senderTransaction =
                new Transaction(
                        sender,
                        Transaction.TransactionType.TRANSFER,
                        amount,
                        Transaction.TransactionStatus.SUCCESS,
                        "Transfer to account "
                                + receiverAccountNumber
                );

        // =====================================================
        // CREATE RECEIVER TRANSACTION
        // =====================================================

        Transaction receiverTransaction =
                new Transaction(
                        receiver,
                        Transaction.TransactionType.TRANSFER,
                        amount,
                        Transaction.TransactionStatus.SUCCESS,
                        "Transfer received from account "
                                + senderAccountNumber
                );

        transactionRepository.save(senderTransaction);
        transactionRepository.save(receiverTransaction);

        return senderTransaction;
    }

    // =========================================================
    // VALIDATE USER STATUS
    // =========================================================

    private void validateUserIsActive(
            User user,
            String userType
    ) {

        if (user == null) {
            throw new IllegalArgumentException(
                    userType + " account owner not found."
            );
        }

        if (user.getStatus() != User.UserStatus.ACTIVE) {

            if (user.getStatus() == User.UserStatus.BLOCKED) {
                throw new IllegalArgumentException(
                        userType + " account owner is blocked. Transaction is not allowed."
                );
            }

            if (user.getStatus() == User.UserStatus.INACTIVE) {
                throw new IllegalArgumentException(
                        userType + " account owner is inactive. Transaction is not allowed."
                );
            }

            throw new IllegalArgumentException(
                    userType + " account owner is not active."
            );
        }
    }

    // =========================================================
    // GET ACCOUNT TRANSACTIONS
    // =========================================================

    public List<Transaction> getTransactions(
            Account account
    ) {

        return transactionRepository
                .findByAccountOrderByCreatedAtDesc(
                        account
                );
    }

    // =========================================================
    // GET TRANSACTIONS FOR MULTIPLE ACCOUNTS
    // =========================================================

    public List<Transaction> getTransactions(
            List<Account> accounts
    ) {

        if (accounts == null ||
                accounts.isEmpty()) {

            return List.of();
        }

        return transactionRepository
                .findByAccountInOrderByCreatedAtDesc(
                        accounts
                );
    }

    // =========================================================
    // GET USER TRANSACTIONS
    // =========================================================

    public List<Transaction> getTransactionsByUser(
            User user
    ) {

        if (user == null) {
            return List.of();
        }

        List<Account> accounts =
                accountRepository.findByUser(user);

        if (accounts == null ||
                accounts.isEmpty()) {

            return List.of();
        }

        return transactionRepository
                .findByAccountInOrderByCreatedAtDesc(
                        accounts
                );
    }

    // =========================================================
    // GET ALL TRANSACTIONS
    // =========================================================

    public List<Transaction> getAllTransactions() {

        return transactionRepository.findAll();
    }
}