package com.om.banking.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "system_settings")
public class SystemSettings {

    @Id
    private Long id;

    @Column(nullable = false, length = 100)
    private String bankName;

    @Column(nullable = false, length = 150)
    private String supportEmail;

    @Column(nullable = false)
    private boolean maintenanceMode;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal maximumTransferAmount;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal minimumAccountBalance;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public SystemSettings() {
    }


    // =========================================================
    // GETTERS AND SETTERS
    // =========================================================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }


    public String getSupportEmail() {
        return supportEmail;
    }

    public void setSupportEmail(String supportEmail) {
        this.supportEmail = supportEmail;
    }


    public boolean isMaintenanceMode() {
        return maintenanceMode;
    }

    public void setMaintenanceMode(
            boolean maintenanceMode
    ) {
        this.maintenanceMode = maintenanceMode;
    }


    public BigDecimal getMaximumTransferAmount() {
        return maximumTransferAmount;
    }

    public void setMaximumTransferAmount(
            BigDecimal maximumTransferAmount
    ) {
        this.maximumTransferAmount =
                maximumTransferAmount;
    }


    public BigDecimal getMinimumAccountBalance() {
        return minimumAccountBalance;
    }

    public void setMinimumAccountBalance(
            BigDecimal minimumAccountBalance
    ) {
        this.minimumAccountBalance =
                minimumAccountBalance;
    }
}