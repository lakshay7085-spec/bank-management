package com.om.banking.service;

import com.om.banking.entity.Account;
import com.om.banking.entity.User;
import com.om.banking.repository.AccountRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class AccountService {

    private final AccountRepository accountRepository;
    private final SystemSettingsService systemSettingsService;

    public AccountService(
            AccountRepository accountRepository,
            SystemSettingsService systemSettingsService
    ) {
        this.accountRepository = accountRepository;
        this.systemSettingsService = systemSettingsService;
    }

    // =========================================================
    // CREATE ACCOUNT
    // =========================================================

    @Transactional
    public Account createAccount(
            User user,
            Account.AccountType accountType
    ) {

        // Check maintenance mode
        if (systemSettingsService
                .getSettings()
                .isMaintenanceMode()) {

            throw new IllegalArgumentException(
                    "New account creation is currently unavailable due to maintenance."
            );
        }

        // Validate user
        if (user == null) {

            throw new IllegalArgumentException(
                    "User is required."
            );
        }

        // Block inactive/blocked users
        validateUserIsActive(user);

        // Validate account type
        if (accountType == null) {

            throw new IllegalArgumentException(
                    "Account type is required."
            );
        }

        Account account =
                new Account();

        account.setAccountNumber(
                generateUniqueAccountNumber()
        );

        account.setAccountType(
                accountType
        );

        account.setBalance(
                BigDecimal.ZERO
        );

        account.setStatus(
                Account.AccountStatus.ACTIVE
        );

        account.setUser(user);

        return accountRepository.save(
                account
        );
    }

    // =========================================================
    // GENERATE ACCOUNT NUMBER
    // =========================================================

    private String generateUniqueAccountNumber() {

        String accountNumber;

        do {

            accountNumber =
                    String.valueOf(
                            Math.abs(
                                    UUID.randomUUID()
                                            .getMostSignificantBits()
                            )
                    ).substring(0, 12);

        } while (
                accountRepository
                        .existsByAccountNumber(
                                accountNumber
                        )
        );

        return accountNumber;
    }

    // =========================================================
    // GET ACCOUNT BY ID
    // =========================================================

    public Optional<Account> getAccountById(
            Long id
    ) {

        return accountRepository.findById(id);
    }

    // =========================================================
    // GET ACCOUNT BY NUMBER
    // =========================================================

    public Optional<Account> getAccountByNumber(
            String accountNumber
    ) {

        return accountRepository
                .findByAccountNumber(
                        accountNumber
                );
    }

    // =========================================================
    // GET USER ACCOUNTS
    // =========================================================

    public List<Account> getAccountsByUser(
            User user
    ) {

        return accountRepository
                .findByUser(user);
    }

    // =========================================================
    // GET USER ACCOUNTS BY ID
    // =========================================================

    public List<Account> getAccountsByUserId(
            Long userId
    ) {

        return accountRepository
                .findByUserId(userId);
    }

    // =========================================================
    // DEPOSIT
    // =========================================================

    @Transactional
    public Account deposit(
            Long accountId,
            BigDecimal amount
    ) {

        checkMaintenanceMode();

        validateAmount(amount);

        Account account =
                getActiveAccount(accountId);

        validateUserIsActive(
                account.getUser()
        );

        account.setBalance(
                account.getBalance()
                        .add(amount)
        );

        return accountRepository.save(
                account
        );
    }

    // =========================================================
    // WITHDRAW
    // =========================================================

    @Transactional
    public Account withdraw(
            Long accountId,
            BigDecimal amount
    ) {

        checkMaintenanceMode();

        validateAmount(amount);

        Account account =
                getActiveAccount(accountId);

        validateUserIsActive(
                account.getUser()
        );

        if (account.getBalance()
                .compareTo(amount) < 0) {

            throw new IllegalArgumentException(
                    "Insufficient account balance."
            );
        }

        var settings =
                systemSettingsService.getSettings();

        BigDecimal remainingBalance =
                account.getBalance()
                        .subtract(amount);

        if (remainingBalance.compareTo(
                settings.getMinimumAccountBalance()
        ) < 0) {

            throw new IllegalArgumentException(
                    "Withdrawal denied. Your account must maintain a minimum balance of ₹"
                            + settings.getMinimumAccountBalance()
            );
        }

        account.setBalance(
                remainingBalance
        );

        return accountRepository.save(
                account
        );
    }

    // =========================================================
    // CHECK MAINTENANCE MODE
    // =========================================================

    private void checkMaintenanceMode() {

        if (systemSettingsService
                .getSettings()
                .isMaintenanceMode()) {

            throw new IllegalArgumentException(
                    "Banking operations are currently unavailable due to maintenance."
            );
        }
    }

    // =========================================================
    // VALIDATE AMOUNT
    // =========================================================

    private void validateAmount(
            BigDecimal amount
    ) {

        if (amount == null ||
                amount.compareTo(
                        BigDecimal.ZERO
                ) <= 0) {

            throw new IllegalArgumentException(
                    "Amount must be greater than zero."
            );
        }
    }

    // =========================================================
    // GET ACTIVE ACCOUNT
    // =========================================================

    private Account getActiveAccount(
            Long accountId
    ) {

        Account account =
                accountRepository
                        .findById(accountId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Account not found."
                                )
                        );

        if (account.getStatus()
                != Account.AccountStatus.ACTIVE) {

            throw new IllegalArgumentException(
                    "Account is not active."
            );
        }

        return account;
    }

    // =========================================================
    // VALIDATE USER STATUS
    // =========================================================

    private void validateUserIsActive(
            User user
    ) {

        if (user == null) {

            throw new IllegalArgumentException(
                    "Account owner not found."
            );
        }

        if (user.getStatus() == User.UserStatus.BLOCKED) {

            throw new IllegalArgumentException(
                    "Your user account is blocked. Banking operations are not allowed."
            );
        }

        if (user.getStatus() == User.UserStatus.INACTIVE) {

            throw new IllegalArgumentException(
                    "Your user account is inactive. Banking operations are not allowed."
            );
        }

        if (user.getStatus() != User.UserStatus.ACTIVE) {

            throw new IllegalArgumentException(
                    "Your user account is not active."
            );
        }
    }
}