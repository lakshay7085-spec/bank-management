package com.om.banking.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }


    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http
    ) throws Exception {

        http

                // =================================================
                // AUTHORIZATION
                // =================================================

                .authorizeHttpRequests(auth -> auth

                        // Public pages
                        .requestMatchers(
                                "/",
                                "/login",
                                "/register",
                                "/css/**",
                                "/js/**",
                                "/images/**"
                        ).permitAll()


                        // Admin pages
                        .requestMatchers("/admin/**")
                        .hasRole("ADMIN")


                        // Customer pages
                        .requestMatchers("/customer/**")
                        .hasRole("CUSTOMER")


                        // Everything else requires login
                        .anyRequest()
                        .authenticated()
                )


                // =================================================
                // LOGIN
                // =================================================

                .formLogin(form -> form

                        .loginPage("/login")

                        .successHandler(
                                (request, response, authentication) -> {

                                    boolean isAdmin =
                                            authentication
                                                    .getAuthorities()
                                                    .stream()
                                                    .anyMatch(
                                                            authority ->
                                                                    authority
                                                                            .getAuthority()
                                                                            .equals("ROLE_ADMIN")
                                                    );

                                    if (isAdmin) {

                                        response.sendRedirect(
                                                "/admin/dashboard"
                                        );

                                    } else {

                                        response.sendRedirect(
                                                "/customer/dashboard"
                                        );
                                    }
                                }
                        )

                        .permitAll()
                )


                // =================================================
                // LOGOUT
                // =================================================

                .logout(logout -> logout

                        .logoutUrl("/logout")

                        .logoutSuccessUrl(
                                "/login?logout"
                        )

                        .invalidateHttpSession(true)

                        .deleteCookies(
                                "JSESSIONID"
                        )

                        .permitAll()
                );


        return http.build();
    }
}