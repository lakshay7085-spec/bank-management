package com.om.banking.repository;

import com.om.banking.entity.Notification;
import com.om.banking.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository
        extends JpaRepository<Notification, Long> {

    List<Notification> findByUserOrderByCreatedAtDesc(User user);

    List<Notification> findByUserIdOrderByCreatedAtDesc(Long userId);

    List<Notification> findByUserIdAndReadStatusFalseOrderByCreatedAtDesc(
            Long userId
    );

    long countByUserIdAndReadStatusFalse(Long userId);
}