package com.om.banking.controller;

import com.om.banking.entity.Account;
import com.om.banking.entity.Transaction;
import com.om.banking.entity.User;
import com.om.banking.repository.AccountRepository;
import com.om.banking.service.TransactionService;
import com.om.banking.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class AdminController {

    private final UserService userService;
    private final TransactionService transactionService;
    private final AccountRepository accountRepository;

    public AdminController(
            UserService userService,
            TransactionService transactionService,
            AccountRepository accountRepository
    ) {
        this.userService = userService;
        this.transactionService = transactionService;
        this.accountRepository = accountRepository;
    }


    // =========================================================
    // ADMIN DASHBOARD
    // =========================================================

    @GetMapping("/admin/dashboard")
    public String dashboard(
            @RequestParam(value = "search", required = false)
            String search,

            @RequestParam(value = "type", required = false)
            String type,

            @RequestParam(value = "status", required = false)
            String status,

            Model model
    ) {

        List<User> users =
                userService.getAllUsers();

        List<Transaction> allTransactions =
                transactionService.getAllTransactions();

        List<Account> accounts =
                accountRepository.findAll();


        // =====================================================
        // FILTER TRANSACTIONS
        // =====================================================

        List<Transaction> filteredTransactions =
                allTransactions.stream()
                        .filter(transaction -> {

                            if (search == null ||
                                    search.trim().isEmpty()) {
                                return true;
                            }

                            String searchText =
                                    search.trim().toLowerCase();

                            String reference =
                                    transaction
                                            .getTransactionReference()
                                            .toLowerCase();

                            String accountNumber =
                                    transaction
                                            .getAccount()
                                            .getAccountNumber()
                                            .toLowerCase();

                            return reference.contains(searchText)
                                    || accountNumber.contains(searchText);
                        })
                        .filter(transaction -> {

                            if (type == null ||
                                    type.trim().isEmpty() ||
                                    type.equalsIgnoreCase("ALL")) {
                                return true;
                            }

                            return transaction
                                    .getTransactionType()
                                    .name()
                                    .equalsIgnoreCase(type);
                        })
                        .filter(transaction -> {

                            if (status == null ||
                                    status.trim().isEmpty() ||
                                    status.equalsIgnoreCase("ALL")) {
                                return true;
                            }

                            return transaction
                                    .getStatus()
                                    .name()
                                    .equalsIgnoreCase(status);
                        })
                        .collect(Collectors.toList());


        // =====================================================
        // USER METRICS
        // =====================================================

        long activeUsers =
                users.stream()
                        .filter(user ->
                                user.getStatus()
                                        == User.UserStatus.ACTIVE)
                        .count();

        long blockedUsers =
                users.stream()
                        .filter(user ->
                                user.getStatus()
                                        == User.UserStatus.BLOCKED)
                        .count();


        // =====================================================
        // ACCOUNT METRICS
        // =====================================================

        long activeAccounts =
                accounts.stream()
                        .filter(account ->
                                account.getStatus()
                                        == Account.AccountStatus.ACTIVE)
                        .count();

        BigDecimal totalBalance =
                accounts.stream()
                        .map(Account::getBalance)
                        .filter(balance -> balance != null)
                        .reduce(
                                BigDecimal.ZERO,
                                BigDecimal::add
                        );


        // =====================================================
        // TRANSACTION METRICS
        // =====================================================

        long successfulTransactions =
                allTransactions.stream()
                        .filter(transaction ->
                                transaction.getStatus()
                                        == Transaction.TransactionStatus.SUCCESS)
                        .count();

        long failedTransactions =
                allTransactions.stream()
                        .filter(transaction ->
                                transaction.getStatus()
                                        == Transaction.TransactionStatus.FAILED)
                        .count();

        BigDecimal totalTransactionAmount =
                allTransactions.stream()
                        .filter(transaction ->
                                transaction.getStatus()
                                        == Transaction.TransactionStatus.SUCCESS)
                        .map(Transaction::getAmount)
                        .filter(amount -> amount != null)
                        .reduce(
                                BigDecimal.ZERO,
                                BigDecimal::add
                        );


        // =====================================================
        // SEND DATA TO THYMELEAF
        // =====================================================

        model.addAttribute(
                "users",
                users
        );

        model.addAttribute(
                "accounts",
                accounts
        );

        model.addAttribute(
                "transactions",
                filteredTransactions
        );

        model.addAttribute(
                "totalUsers",
                users.size()
        );

        model.addAttribute(
                "activeUsers",
                activeUsers
        );

        model.addAttribute(
                "blockedUsers",
                blockedUsers
        );

        model.addAttribute(
                "totalAccounts",
                accounts.size()
        );

        model.addAttribute(
                "activeAccounts",
                activeAccounts
        );

        model.addAttribute(
                "totalBalance",
                totalBalance
        );

        model.addAttribute(
                "totalTransactions",
                allTransactions.size()
        );

        model.addAttribute(
                "successfulTransactions",
                successfulTransactions
        );

        model.addAttribute(
                "failedTransactions",
                failedTransactions
        );

        model.addAttribute(
                "totalTransactionAmount",
                totalTransactionAmount
        );

        model.addAttribute(
                "search",
                search
        );

        model.addAttribute(
                "selectedType",
                type
        );

        model.addAttribute(
                "selectedStatus",
                status
        );

        model.addAttribute(
                "filteredTransactionCount",
                filteredTransactions.size()
        );


        return "admin-dashboard";
    }


    // =========================================================
    // USER MANAGEMENT PAGE
    // =========================================================

    @GetMapping("/admin/users")
    public String users(Model model) {

        List<User> users =
                userService.getAllUsers();

        model.addAttribute(
                "users",
                users
        );

        return "admin-users";
    }


    // =========================================================
    // EDIT USER PAGE
    // =========================================================

    @GetMapping("/admin/users/{id}/edit")
    public String editUserPage(
            @PathVariable Long id,
            Model model
    ) {

        User user =
                userService
                        .getUserById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User not found."
                                )
                        );

        model.addAttribute(
                "user",
                user
        );

        return "admin-edit-user";
    }


    // =========================================================
    // UPDATE USER
    // =========================================================

    @PostMapping("/admin/users/{id}/edit")
    public String updateUser(
            @PathVariable Long id,

            @RequestParam("name")
            String name,

            @RequestParam("phone")
            String phone,

            @RequestParam("role")
            User.Role role,

            @RequestParam("status")
            User.UserStatus status
    ) {

        User updatedUser =
                new User();

        updatedUser.setName(name);
        updatedUser.setPhone(phone);
        updatedUser.setRole(role);
        updatedUser.setStatus(status);

        userService.updateUser(
                id,
                updatedUser
        );

        return "redirect:/admin/users?updated";
    }


    // =========================================================
    // DELETE USER
    // =========================================================

    @PostMapping("/admin/users/{id}/delete")
    public String deleteUser(
            @PathVariable Long id
    ) {

        userService.deleteUser(id);

        return "redirect:/admin/users?deleted";
    }


    // =========================================================
    // ACTIVATE USER
    // =========================================================

    @PostMapping("/admin/users/{id}/activate")
    public String activateUser(
            @PathVariable Long id
    ) {

        userService.activateUser(id);

        return "redirect:/admin/users?activated";
    }


    // =========================================================
    // DEACTIVATE USER
    // =========================================================

    @PostMapping("/admin/users/{id}/deactivate")
    public String deactivateUser(
            @PathVariable Long id
    ) {

        userService.deactivateUser(id);

        return "redirect:/admin/users?deactivated";
    }


    // =========================================================
    // BLOCK USER
    // =========================================================

    @PostMapping("/admin/users/{id}/block")
    public String blockUser(
            @PathVariable Long id
    ) {

        userService.blockUser(id);

        return "redirect:/admin/users?blocked";
    }
}