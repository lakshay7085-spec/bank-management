package com.om.banking.controller;

import com.om.banking.entity.Account;
import com.om.banking.entity.Transaction;
import com.om.banking.entity.User;
import com.om.banking.service.AccountService;
import com.om.banking.service.TransactionService;
import com.om.banking.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@Controller
public class CustomerController {

    private final UserService userService;
    private final AccountService accountService;
    private final TransactionService transactionService;

    public CustomerController(
            UserService userService,
            AccountService accountService,
            TransactionService transactionService
    ) {

        this.userService = userService;
        this.accountService = accountService;
        this.transactionService = transactionService;
    }


    // =========================================================
    // CUSTOMER DASHBOARD
    // =========================================================

    @GetMapping("/customer/dashboard")
    public String dashboard(
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        List<Account> accounts =
                accountService
                        .getAccountsByUser(user);

        model.addAttribute(
                "user",
                user
        );

        model.addAttribute(
                "accounts",
                accounts
        );

        return "customer-dashboard";
    }


    // =========================================================
    // OPEN ACCOUNT PAGE
    // =========================================================

    @GetMapping("/customer/accounts/open")
    public String openAccountPage() {

        return "open-account";
    }


    // =========================================================
    // CREATE ACCOUNT
    // =========================================================

    @PostMapping("/customer/accounts/open")
    public String openAccount(
            @RequestParam("accountType")
            Account.AccountType accountType,

            Authentication authentication
    ) {

        User user =
                getLoggedInUser(authentication);

        accountService.createAccount(
                user,
                accountType
        );

        return "redirect:/customer/dashboard?accountCreated";
    }


    // =========================================================
    // ACCOUNT DETAILS
    // =========================================================

    @GetMapping("/customer/accounts/{id}")
    public String accountDetails(
            @PathVariable Long id,
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        Account account =
                getCustomerAccount(
                        id,
                        user
                );

        model.addAttribute(
                "user",
                user
        );

        model.addAttribute(
                "account",
                account
        );

        return "account-details";
    }


    // =========================================================
    // DEPOSIT PAGE
    // =========================================================

    @GetMapping(
            "/customer/accounts/{id}/deposit"
    )
    public String depositPage(
            @PathVariable Long id,
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        Account account =
                getCustomerAccount(
                        id,
                        user
                );

        model.addAttribute(
                "account",
                account
        );

        return "deposit";
    }


    // =========================================================
    // DEPOSIT
    // =========================================================

    @PostMapping(
            "/customer/accounts/{id}/deposit"
    )
    public String deposit(
            @PathVariable Long id,

            @RequestParam("amount")
            BigDecimal amount,

            Authentication authentication
    ) {

        User user =
                getLoggedInUser(authentication);

        getCustomerAccount(
                id,
                user
        );

        try {

            accountService.deposit(
                    id,
                    amount
            );

            return "redirect:/customer/accounts/"
                    + id
                    + "?depositSuccess";

        } catch (
                IllegalArgumentException exception
        ) {

            return "redirect:/customer/accounts/"
                    + id
                    + "/deposit?error="
                    + encodeMessage(
                    exception.getMessage()
            );
        }
    }


    // =========================================================
    // WITHDRAW PAGE
    // =========================================================

    @GetMapping(
            "/customer/accounts/{id}/withdraw"
    )
    public String withdrawPage(
            @PathVariable Long id,
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        Account account =
                getCustomerAccount(
                        id,
                        user
                );

        model.addAttribute(
                "account",
                account
        );

        return "withdraw";
    }


    // =========================================================
    // WITHDRAW
    // =========================================================

    @PostMapping(
            "/customer/accounts/{id}/withdraw"
    )
    public String withdraw(
            @PathVariable Long id,

            @RequestParam("amount")
            BigDecimal amount,

            Authentication authentication
    ) {

        User user =
                getLoggedInUser(authentication);

        getCustomerAccount(
                id,
                user
        );

        try {

            accountService.withdraw(
                    id,
                    amount
            );

            return "redirect:/customer/accounts/"
                    + id
                    + "?withdrawSuccess";

        } catch (
                IllegalArgumentException exception
        ) {

            return "redirect:/customer/accounts/"
                    + id
                    + "/withdraw?error="
                    + encodeMessage(
                    exception.getMessage()
            );
        }
    }


    // =========================================================
    // TRANSFER PAGE
    // =========================================================

    @GetMapping("/customer/transfer")
    public String transferPage(
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        List<Account> accounts =
                accountService
                        .getAccountsByUser(user);

        model.addAttribute(
                "accounts",
                accounts
        );

        return "transfer";
    }


    // =========================================================
    // TRANSFER MONEY
    // =========================================================

    @PostMapping("/customer/transfer")
    public String transfer(
            @RequestParam("senderAccountId")
            Long senderAccountId,

            @RequestParam("receiverAccountNumber")
            String receiverAccountNumber,

            @RequestParam("amount")
            BigDecimal amount,

            Authentication authentication,

            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        try {

            // Make sure the selected account
            // belongs to the logged-in customer.

            Account sender =
                    getCustomerAccount(
                            senderAccountId,
                            user
                    );


            // Make sure sender account is active.

            if (sender.getStatus()
                    != Account.AccountStatus.ACTIVE) {

                throw new IllegalArgumentException(
                        "Sender account is not active."
                );
            }


            // Validate receiver account number.

            if (receiverAccountNumber == null ||
                    receiverAccountNumber.trim().isEmpty()) {

                throw new IllegalArgumentException(
                        "Recipient account number is required."
                );
            }


            // Perform transfer.

            Transaction transaction =
                    transactionService.transferMoney(
                            sender.getAccountNumber(),
                            receiverAccountNumber.trim(),
                            amount
                    );


            // Reload accounts after transfer.

            List<Account> accounts =
                    accountService
                            .getAccountsByUser(user);

            model.addAttribute(
                    "accounts",
                    accounts
            );

            model.addAttribute(
                    "successMessage",
                    "Transfer successful. Transaction reference: "
                            + transaction.getTransactionReference()
            );

            return "transfer";

        } catch (
                IllegalArgumentException exception
        ) {

            List<Account> accounts =
                    accountService
                            .getAccountsByUser(user);

            model.addAttribute(
                    "accounts",
                    accounts
            );

            model.addAttribute(
                    "errorMessage",
                    exception.getMessage()
            );

            return "transfer";
        }
    }


    // =========================================================
    // TRANSACTION HISTORY
    // =========================================================

    @GetMapping("/customer/transactions")
    public String transactions(
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        List<Transaction> transactions =
                transactionService
                        .getTransactionsByUser(user);

        model.addAttribute(
                "user",
                user
        );

        model.addAttribute(
                "transactions",
                transactions
        );

        return "transactions";
    }


    // =========================================================
    // CUSTOMER PROFILE PAGE
    // =========================================================

    @GetMapping("/customer/profile")
    public String profilePage(
            Authentication authentication,
            Model model
    ) {

        User user =
                getLoggedInUser(authentication);

        model.addAttribute(
                "user",
                user
        );

        return "profile";
    }


    // =========================================================
    // UPDATE CUSTOMER PROFILE
    // =========================================================

    @PostMapping("/customer/profile")
    public String updateProfile(
            @RequestParam("name")
            String name,

            @RequestParam("email")
            String email,

            @RequestParam(
                    value = "phone",
                    required = false
            )
            String phone,

            @RequestParam(
                    value = "newPassword",
                    required = false
            )
            String newPassword,

            Authentication authentication
    ) {

        User user =
                getLoggedInUser(authentication);

        String oldEmail =
                user.getEmail();

        try {

            User updatedUser =
                    userService.updateProfile(
                            user.getId(),
                            name,
                            email,
                            phone,
                            newPassword
                    );


            /*
             * If the email changed, update the
             * current Spring Security authentication
             * so the user does not get logged out
             * immediately after saving the profile.
             */

            if (!oldEmail.equals(
                    updatedUser.getEmail()
            )) {

                UsernamePasswordAuthenticationToken
                        newAuthentication =
                        new UsernamePasswordAuthenticationToken(
                                updatedUser.getEmail(),
                                authentication.getCredentials(),
                                authentication.getAuthorities()
                        );

                SecurityContextHolder
                        .getContext()
                        .setAuthentication(
                                newAuthentication
                        );
            }


            return "redirect:/customer/profile?success";

        } catch (
                IllegalArgumentException exception
        ) {

            return "redirect:/customer/profile?error="
                    + encodeMessage(
                    exception.getMessage()
            );
        }
    }


    // =========================================================
    // GET LOGGED-IN USER
    // =========================================================

    private User getLoggedInUser(
            Authentication authentication
    ) {

        return userService
                .getUserByEmail(
                        authentication.getName()
                )
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "User account not found."
                        )
                );
    }


    // =========================================================
    // GET CUSTOMER ACCOUNT
    // =========================================================

    private Account getCustomerAccount(
            Long accountId,
            User user
    ) {

        Account account =
                accountService
                        .getAccountById(accountId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Account not found."
                                )
                        );


        if (
                account.getUser() == null
                        || account.getUser().getId() == null
                        || !account.getUser()
                        .getId()
                        .equals(user.getId())
        ) {

            throw new IllegalArgumentException(
                    "You are not authorized to access this account."
            );
        }

        return account;
    }


    // =========================================================
    // URL MESSAGE ENCODING
    // =========================================================

    private String encodeMessage(
            String message
    ) {

        if (message == null) {

            return "Operation+failed.";
        }

        return message.replace(
                " ",
                "+"
        );
    }
}