package com.om.banking.repository;

import com.om.banking.entity.Beneficiary;
import com.om.banking.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Long> {

    List<Beneficiary> findByUser(User user);

    List<Beneficiary> findByUserId(Long userId);

    Optional<Beneficiary> findByAccountNumberAndUser(
            String accountNumber,
            User user
    );

    boolean existsByAccountNumberAndUser(
            String accountNumber,
            User user
    );
}