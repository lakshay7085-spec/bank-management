package com.om.banking.service;

import com.om.banking.entity.Notification;
import com.om.banking.entity.User;
import com.om.banking.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(
            NotificationRepository notificationRepository
    ) {
        this.notificationRepository = notificationRepository;
    }

    // Create notification
    @Transactional
    public Notification createNotification(
            User user,
            String title,
            String message,
            Notification.NotificationType type
    ) {

        Notification notification = new Notification();

        notification.setUser(user);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setType(type);
        notification.setRead(false);

        return notificationRepository.save(notification);
    }

    // Get all notifications for a user
    public List<Notification> getUserNotifications(
            User user
    ) {

        return notificationRepository
                .findByUserOrderByCreatedAtDesc(user);
    }

    // Get notifications by user ID
    public List<Notification> getUserNotificationsByUserId(
            Long userId
    ) {

        return notificationRepository
                .findByUserIdOrderByCreatedAtDesc(userId);
    }

    // Get unread notifications
    public List<Notification> getUnreadNotifications(
            Long userId
    ) {

        return notificationRepository
                .findByUserIdAndReadStatusFalseOrderByCreatedAtDesc(
                        userId
                );
    }

    // Count unread notifications
    public long countUnreadNotifications(Long userId) {

        return notificationRepository
                .countByUserIdAndReadStatusFalse(userId);
    }

    // Mark notification as read
    @Transactional
    public Notification markAsRead(Long id) {

        Notification notification = notificationRepository
                .findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Notification not found."
                        )
                );

        notification.setRead(true);

        return notificationRepository.save(notification);
    }

    // Mark all notifications as read
    @Transactional
    public void markAllAsRead(Long userId) {

        List<Notification> notifications =
                notificationRepository
                        .findByUserIdOrderByCreatedAtDesc(userId);

        for (Notification notification : notifications) {
            notification.setRead(true);
        }

        notificationRepository.saveAll(notifications);
    }

    // Delete notification
    @Transactional
    public void deleteNotification(Long id) {

        if (!notificationRepository.existsById(id)) {
            throw new IllegalArgumentException(
                    "Notification not found."
            );
        }

        notificationRepository.deleteById(id);
    }
}