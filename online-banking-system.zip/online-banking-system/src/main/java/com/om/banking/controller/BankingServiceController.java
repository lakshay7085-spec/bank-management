package com.om.banking.controller;

import com.om.banking.entity.User;
import com.om.banking.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BankingServiceController {

    private final UserService userService;

    public BankingServiceController(
            UserService userService
    ) {
        this.userService = userService;
    }


    // =========================================================
    // BANKING SERVICES PAGE
    // =========================================================

    @GetMapping("/customer/services")
    public String bankingServices(
            @RequestParam(
                    value = "service",
                    required = false
            )
            String service,

            Model model,

            org.springframework.security.core.Authentication authentication
    ) {

        User user =
                userService
                        .getUserByEmail(
                                authentication.getName()
                        )
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User account not found."
                                )
                        );

        model.addAttribute(
                "user",
                user
        );


        // Default service

        if (service == null ||
                service.trim().isEmpty()) {

            service = "overview";
        }


        model.addAttribute(
                "selectedService",
                service
        );


        // =====================================================
        // LOAN DETAILS
        // =====================================================

        if (service.equalsIgnoreCase("loans")) {

            model.addAttribute(
                    "serviceTitle",
                    "Loans"
            );

            model.addAttribute(
                    "serviceDescription",
                    "Explore available loan services for personal and financial needs."
            );

            model.addAttribute(
                    "serviceType",
                    "loan"
            );

            model.addAttribute(
                    "loanFeatures",
                    new String[]{
                            "Personal Loan",
                            "Home Loan",
                            "Education Loan",
                            "Vehicle Loan"
                    }
            );
        }


        // =====================================================
        // INVESTMENT DETAILS
        // =====================================================

        else if (
                service.equalsIgnoreCase(
                        "investments"
                )
        ) {

            model.addAttribute(
                    "serviceTitle",
                    "Investments"
            );

            model.addAttribute(
                    "serviceDescription",
                    "Explore investment options designed to help customers grow their savings."
            );

            model.addAttribute(
                    "serviceType",
                    "investment"
            );

            model.addAttribute(
                    "investmentFeatures",
                    new String[]{
                            "Fixed Deposits",
                            "Recurring Deposits",
                            "Mutual Funds",
                            "Long-Term Savings"
                    }
            );
        }


        // =====================================================
        // SERVICE OVERVIEW
        // =====================================================

        else {

            model.addAttribute(
                    "serviceTitle",
                    "Banking Services"
            );

            model.addAttribute(
                    "serviceDescription",
                    "Access banking services including loans and investment options."
            );

            model.addAttribute(
                    "serviceType",
                    "overview"
            );
        }


        return "banking-services";
    }
}