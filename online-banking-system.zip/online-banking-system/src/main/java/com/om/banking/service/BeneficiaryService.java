package com.om.banking.service;

import com.om.banking.entity.Beneficiary;
import com.om.banking.entity.User;
import com.om.banking.repository.BeneficiaryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BeneficiaryService {

    private final BeneficiaryRepository beneficiaryRepository;

    public BeneficiaryService(BeneficiaryRepository beneficiaryRepository) {
        this.beneficiaryRepository = beneficiaryRepository;
    }

    // Add a beneficiary
    @Transactional
    public Beneficiary addBeneficiary(
            User user,
            String beneficiaryName,
            String accountNumber,
            String ifscCode,
            String bankName
    ) {

        if (beneficiaryRepository
                .existsByAccountNumberAndUser(accountNumber, user)) {

            throw new IllegalArgumentException(
                    "This beneficiary already exists."
            );
        }

        Beneficiary beneficiary = new Beneficiary();

        beneficiary.setUser(user);
        beneficiary.setBeneficiaryName(beneficiaryName);
        beneficiary.setAccountNumber(accountNumber);
        beneficiary.setIfscCode(ifscCode);
        beneficiary.setBankName(bankName);
        beneficiary.setStatus(
                Beneficiary.BeneficiaryStatus.ACTIVE
        );

        return beneficiaryRepository.save(beneficiary);
    }

    // Get all beneficiaries
    public List<Beneficiary> getBeneficiaries(User user) {
        return beneficiaryRepository.findByUser(user);
    }

    // Get beneficiaries by user ID
    public List<Beneficiary> getBeneficiariesByUserId(Long userId) {
        return beneficiaryRepository.findByUserId(userId);
    }

    // Remove/deactivate beneficiary
    @Transactional
    public Beneficiary deactivateBeneficiary(Long id) {

        Beneficiary beneficiary = beneficiaryRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Beneficiary not found."
                        )
                );

        beneficiary.setStatus(
                Beneficiary.BeneficiaryStatus.INACTIVE
        );

        return beneficiaryRepository.save(beneficiary);
    }
}