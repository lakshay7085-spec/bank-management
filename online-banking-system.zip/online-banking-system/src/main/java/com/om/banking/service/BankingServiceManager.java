package com.om.banking.service;

import com.om.banking.entity.BankingService;
import com.om.banking.repository.BankingServiceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class BankingServiceManager {

    private final BankingServiceRepository bankingServiceRepository;

    public BankingServiceManager(
            BankingServiceRepository bankingServiceRepository
    ) {
        this.bankingServiceRepository = bankingServiceRepository;
    }

    // Create a banking service
    @Transactional
    public BankingService createService(
            String serviceName,
            String description,
            BankingService.ServiceType serviceType
    ) {

        if (bankingServiceRepository
                .existsByServiceName(serviceName)) {

            throw new IllegalArgumentException(
                    "A service with this name already exists."
            );
        }

        BankingService service = new BankingService();

        service.setServiceName(serviceName);
        service.setDescription(description);
        service.setServiceType(serviceType);
        service.setStatus(
                BankingService.ServiceStatus.ACTIVE
        );

        return bankingServiceRepository.save(service);
    }

    // Get service by ID
    public Optional<BankingService> getServiceById(Long id) {
        return bankingServiceRepository.findById(id);
    }

    // Get service by name
    public Optional<BankingService> getServiceByName(
            String serviceName
    ) {

        return bankingServiceRepository
                .findByServiceName(serviceName);
    }

    // Get all services
    public List<BankingService> getAllServices() {
        return bankingServiceRepository.findAll();
    }

    // Get active services
    public List<BankingService> getActiveServices() {

        return bankingServiceRepository.findByStatus(
                BankingService.ServiceStatus.ACTIVE
        );
    }

    // Deactivate service
    @Transactional
    public BankingService deactivateService(Long id) {

        BankingService service = bankingServiceRepository
                .findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Banking service not found."
                        )
                );

        service.setStatus(
                BankingService.ServiceStatus.INACTIVE
        );

        return bankingServiceRepository.save(service);
    }

    // Activate service
    @Transactional
    public BankingService activateService(Long id) {

        BankingService service = bankingServiceRepository
                .findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Banking service not found."
                        )
                );

        service.setStatus(
                BankingService.ServiceStatus.ACTIVE
        );

        return bankingServiceRepository.save(service);
    }
}