package com.om.banking.repository;

import com.om.banking.entity.ServiceRequest;
import com.om.banking.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ServiceRequestRepository
        extends JpaRepository<ServiceRequest, Long> {

    List<ServiceRequest> findByUser(User user);

    List<ServiceRequest> findByUserId(Long userId);

    List<ServiceRequest> findByStatus(
            ServiceRequest.RequestStatus status
    );

    List<ServiceRequest> findByUserIdAndStatus(
            Long userId,
            ServiceRequest.RequestStatus status
    );
}