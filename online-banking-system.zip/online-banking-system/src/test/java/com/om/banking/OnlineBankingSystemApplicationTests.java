package com.om.banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBankingSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
